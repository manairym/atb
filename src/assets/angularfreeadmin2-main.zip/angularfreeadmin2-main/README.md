# angularfreeadmin2
Create Animated Responsive Admin Dashboard Template using Angular 16, Html, CSS and Charts<br>
[Code Snippet & Live Demo
](https://therichpost.com/create-animated-responsive-admin-dashboard-template-using-angular-16-html-css-and-charts/)
